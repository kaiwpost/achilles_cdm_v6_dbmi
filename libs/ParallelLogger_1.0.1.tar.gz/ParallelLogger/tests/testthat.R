library(testthat)
test_check("ParallelLogger")
